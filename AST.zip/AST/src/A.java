class A {

  public boolean methodA() {
    return true;
  }

  private void methodB(int param1, int param2) {

  }

  private void methodB(int param1, boolean param2) {

  }

}